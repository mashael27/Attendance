class AssignmentDetailsController < ApplicationController
  def index
  end
end

require "test_helper"

class ShiftAssignmentTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end

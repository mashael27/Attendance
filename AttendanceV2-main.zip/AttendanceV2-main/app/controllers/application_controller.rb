class ApplicationController < ActionController::Base
  include ApplicationHelper
end

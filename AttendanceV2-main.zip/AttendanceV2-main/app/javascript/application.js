import "@hotwired/turbo-rails"
import "./controllers"
import * as bootstrap from "bootstrap"
// import jquery from 'jquery'
// window.$ = jquery


module AttendanceHelper
end

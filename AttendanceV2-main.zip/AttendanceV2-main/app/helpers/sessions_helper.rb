# app/helpers/session_helper.rb
module SessionsHelper
end
